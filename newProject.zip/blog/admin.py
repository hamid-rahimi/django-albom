from django.contrib import admin
from blog.models import Article,Person

admin.site.register(Article)
admin.site.register(Person)

